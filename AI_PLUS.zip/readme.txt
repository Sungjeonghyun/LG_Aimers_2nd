AI PLUS : 성정현, 성지훈, 김은지, 홍진우

코드 : code.ipynb
모델 : model.cbm
데이터 : train.csv, test.csv, sample_submission.csv

실행 환경은 Windows 10, Python 3.9 입니다.
마지막 모델 학습은 GPU로 진행했기 때문에, 결과가 변동될 수 있습니다.
.cbm 확장자는 결과로 제출하는 catboost 모델입니다.

문의 사항이 있으시면
sjhkr96@gmail.com 으로 연락주시면 감사합니다.